<template>
  <div class="pagination-area">
    <a href="#" class="prev page-numbers">
      <i class="fas fa-chevron-left"></i>
    </a>
    <a href="#" class="page-numbers">1</a>
    <span class="page-numbers current" aria-current="page">2</span>
    <a href="#" class="page-numbers">3</a>
    <a href="#" class="page-numbers">4</a>
    <a href="#" class="next page-numbers">
      <i class="fas fa-chevron-right"></i>
    </a>
  </div>
</template>

<script>
export default {};
</script>

<style lang="less">
</style>