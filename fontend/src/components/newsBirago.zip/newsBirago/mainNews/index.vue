<template>
    <div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-1.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Politics</span>
              <h3>
                <a href="#"
                  >Trump discusses various issues with his party’s
                  political leaders.</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-2.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Business</span>
              <h3>
                <a href="#"
                  >Follow some simple rules to invest money in any
                  business</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-3.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Sport</span>
              <h3>
                <a href="#"
                  >Manchester United’s dream of winning by a goal was
                  fulfilled</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-4.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Tech</span>
              <h3>
                <a href="#"
                  >All new gadgets are being made in technology.</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-5.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Culture</span>
              <h3>
                <a href="#"
                  >A group of artists performed music in a group way</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-6.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Politics</span>
              <h3>
                <a href="#"
                  >Organizing a conference among our selves to make it
                  better financially.</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-7.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>News</span>
              <h3>
                <a href="#"
                  >A few months later, the stock market set a new
                  record.</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-8.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Music</span>
              <h3>
                <a href="#"
                  >The liberated new album is the best solo record to
                  date</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-9.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Culture</span>
              <h3>
                <a href="#"
                  >After a long period the people of different countries
                  have become vocal again.</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-10.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Fitness</span>
              <h3>
                <a href="#"
                  >Morning yoga is very important for maintaining good
                  physical fitness</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-11.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Sport</span>
              <h3>
                <a href="#"
                  >Tourist centers of different countries have once again
                  become popular.</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-12.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Culture</span>
              <h3>
                <a href="#">Love songs helped me through heartbreak</a>
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-13.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Covid-19</span>
              <h3>
                <a href="#"
                  >The Covid-19 vaccine is being given as a test</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-14.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Races</span>
              <h3>
                <a href="#"
                  >Africa holds the first place in the women's race</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
      <div class="single-news-item">
        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="news-image">
              <a href="#">
                <img
                  src="../../../assets/news/news/news-15.jpg"
                  alt="image"
                />
              </a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="news-content">
              <span>Boxing</span>
              <h3>
                <a href="#"
                  >A fierce battle is going on between the two in the
                  game</a
                >
              </h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna
                aliqua.
              </p>
              <p><a href="#">Patricia</a> / 28 September, 2021</p>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="less">

</style>