<template>
  <div>
    <section class="widget widget_popular_posts_thumb">
      <h3 class="widget-title">Popular posts</h3>
      <article class="item">
        <a href="#" class="thumb">
          <span class="fullimage cover bg1" role="img"></span>
        </a>
        <div class="info">
          <h4 class="title usmall">
            <a href="#"
              >Match between United States and England at AGD stadium</a
            >
          </h4>
          <span>28 September, 2021</span>
        </div>
      </article>
      <article class="item">
        <a href="#" class="thumb">
          <span class="fullimage cover bg2" role="img"></span>
        </a>
        <div class="info">
          <h4 class="title usmall">
            <a href="#">For the last time, he addressed the people</a>
          </h4>
          <span>28 September, 2021</span>
        </div>
      </article>
      <article class="item">
        <a href="#" class="thumb">
          <span class="fullimage cover bg3" role="img"></span>
        </a>
        <div class="info">
          <h4 class="title usmall">
            <a href="#">The coronavairus is finished and the outfit is busy</a>
          </h4>
          <span>28 September, 2021</span>
        </div>
      </article>
      <article class="item">
        <a href="#" class="thumb">
          <span class="fullimage cover bg4" role="img"></span>
        </a>
        <div class="info">
          <h4 class="title usmall">
            <a href="#"
              >A fierce battle is going on between the two in the game</a
            >
          </h4>
          <span>28 September, 2021</span>
        </div>
      </article>
      <article class="item">
        <a href="#" class="thumb">
          <span class="fullimage cover bg5" role="img"></span>
        </a>
        <div class="info">
          <h4 class="title usmall">
            <a href="#"
              >Negotiations on a peace agreement between the two countries</a
            >
          </h4>
          <span>28 September, 2021</span>
        </div>
      </article>
    </section>
  </div>
</template>

<script>
export default {};
</script>

<style lang="less">
</style>