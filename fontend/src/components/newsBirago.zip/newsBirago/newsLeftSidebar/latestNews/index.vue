<template>
  <div>
    <section class="widget widget_latest_news_thumb">
      <h3 class="widget-title">Latest news</h3>
      <article class="item">
        <a href="#" class="thumb">
          <span class="fullimage cover bg1" role="img"></span>
        </a>
        <div class="info">
          <h4 class="title usmall">
            <a href="#"
              >Negotiations on a peace agreement between the two countries</a>
          </h4>
          <span>28 September, 2021</span>
        </div>
      </article>
      <article class="item">
        <a href="#" class="thumb">
          <span class="fullimage cover bg2" role="img"></span>
        </a>
        <div class="info">
          <h4 class="title usmall">
            <a href="#">Love songs helped me through heartbreak</a>
          </h4>
          <span>28 September, 2021</span>
        </div>
      </article>
      <article class="item">
        <a href="#" class="thumb">
          <span class="fullimage cover bg3" role="img"></span>
        </a>
        <div class="info">
          <h4 class="title usmall">
            <a href="#">This movement aims to establish women rights</a>
          </h4>
          <span>28 September, 2021</span>
        </div>
      </article>
      <article class="item">
        <a href="#" class="thumb">
          <span class="fullimage cover bg4" role="img"></span>
        </a>
        <div class="info">
          <h4 class="title usmall">
            <a href="#"
              >Giving special powers to police officers to prevent crime</a
            >
          </h4>
          <span>28 September, 2021</span>
        </div>
      </article>
      <article class="item">
        <a href="#" class="thumb">
          <span class="fullimage cover bg5" role="img"></span>
        </a>
        <div class="info">
          <h4 class="title usmall">
            <a href="#">Copy paste the style of your element Newspaper</a>
          </h4>
          <span>28 September, 2021</span>
        </div>
      </article>
    </section>
  </div>
</template>
     
<script>
export default {};
</script>

<style lang="less">
</style>